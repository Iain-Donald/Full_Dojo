using System;
using Microsoft.AspNetCore.Mvc;
namespace DojoSurvey
{
    public class HomeController : Controller{
        [HttpGet("")]
        public ViewResult index(){
            return View();
        }


        [HttpPost]
        [Route("result")]
        public IActionResult result(string name, string location, string favoriteLang, string comment){ 
            ViewBag.name = name;
            ViewBag.location = location;
            ViewBag.favoriteLang = favoriteLang;
            ViewBag.comment = comment;
            return View();
        }
    }
}