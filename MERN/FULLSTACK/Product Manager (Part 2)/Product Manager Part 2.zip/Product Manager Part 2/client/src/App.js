import React from "react";
import Main from './views/Main';
import Details from './components/Details';
import {
  BrowserRouter,
  Routes,
  Route,
  Link 
} from "react-router-dom";
    
import { useParams } from "react-router";
function App() {
  return (
    <div>
      <BrowserRouter>
      <h1>Routing Example</h1>
      <p>
        <Link to="/">Main</Link>
        | 
        <Link to="/details">Details</Link>   
      </p>
      <Routes>
        <Route path='/details/:id' element={<Details/>} />
        <Route path='/' element={<Main/>} />
      </Routes>
    </BrowserRouter>
    </div>
  );
}
export default App;