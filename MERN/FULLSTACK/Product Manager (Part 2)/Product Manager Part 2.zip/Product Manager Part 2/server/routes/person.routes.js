const PersonController = require('../controllers/person.controller');
const DisplayController = require('../controllers/display.controller');
const PersonModel = require('../models/person.model')
module.exports = function(app){
    app.get('/api', PersonModel.findAllUsers);
    app.get('/api/getByID/:id', PersonController.getByID);
    app.post('/api/people', PersonController.createPerson);
    //app.get('/api/display', DisplayController.index);
}