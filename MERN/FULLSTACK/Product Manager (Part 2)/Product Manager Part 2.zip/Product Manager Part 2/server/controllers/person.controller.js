const { Person } = require('../models/person.model');
const mongoose = require('mongoose');


module.exports.getByID = (request, response) => {
    Person.findOne({ _id: request.params.id })
        .then(oneSingleUser => response.json({ user: oneSingleUser }))
        .catch(err => response.json({ message: 'Something went wrong', error: err }));
}

module.exports.createPerson = (request, response) => {
    const {title, price, description } = request.body;
    Person.create({
        title, 
        price,
        description
    })
        .then(person=>response.json(person))
        .catch(err=>response.json(err));
}