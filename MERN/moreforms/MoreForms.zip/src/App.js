import React from 'react';
import './App.css';
import Forms from './components/Forms';

function App() {
  return (
    <div className="App">
      <Forms />
    </div>
  );
}

export default App;
