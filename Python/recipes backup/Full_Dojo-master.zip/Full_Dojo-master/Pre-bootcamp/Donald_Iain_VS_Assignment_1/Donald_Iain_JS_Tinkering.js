var childheight = 100;

function displayIfChildIsAbleToRideTheRollerCoaster(height){
    
}