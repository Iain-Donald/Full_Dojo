var childheight = 100;

function displayIfChildIsAbleToRideTheRollerCoaster(height){
    if(height > 52){
        console.log("Get on that ride, kiddo!");
    } else {
        
    }
}