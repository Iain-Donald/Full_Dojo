num2 = "name"
print(type(num2))
print("test")