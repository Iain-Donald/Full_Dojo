# h1
## h2
### h3

- bullet points
1. number 1
2. number 2

```
code
```

```js
list = ['tyler', 'joe', 'curtis'];
for(var i=0; i < list.length; i++){
    console.log(list[i]);
}
```

```py
list = ['tyler', 'joe', 'curtis']
for i in range(len(list)):
    print(list[i])

for item in list:
    print(item)
```

# data types

| type |js | python |
| - | - | - |
|strings|"3"|"1"| 
|integers|3|numbers: 1 or 1.0
|floats|3.0| ^^^
|booleans|true/false| True/False (capitalization)
|undefined|
|arrays|[]|
|objects|()|