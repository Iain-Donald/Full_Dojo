from python import Something

s1 = Something()

s1.info()