class Something:
    def __init__(self):
        pass
    def info(self):
        print(__name__)

s1 = Something()
s1.info()