
INSERT INTO dojos (name)
VALUES('dojo1'), ('dojo2'), ('dojo3');