class Character:
    def __init__(name, strength, health, defence, speed):
        self.name = name
        self.strength = strength
        self.health = 100
        self.defence = 10
        self.speed = speed

    

